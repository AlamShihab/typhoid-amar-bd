# Data sources

## S1 Data (the only data used in the core analysis)

- **Citation:** Tanmoy AM, Hooda Y, Sajib MSI, et al. (2024) Trends in antimicrobial resistance amongst *Salmonella* Typhi in Bangladesh: A 24-year retrospective observational study (1999–2022). *PLoS Negl Trop Dis* 18(10): e0012558. https://doi.org/10.1371/journal.pntd.0012558
- **File:** S1 Data, "Antimicrobial resistance dataset of 12,435 typhoid cases in Bangladesh from 1999–2022"
- **Download URL:** https://journals.plos.org/plosntds/article/file?type=supplementary&id=10.1371/journal.pntd.0012558.s001
- **Saved as:** `data/raw/S1_Data.xlsx` (original file name `journal.pntd.0012558.s001.xlsx`)
- **Downloaded:** 20 October 2026
- **Licence:** Creative Commons Attribution 4.0 (CC BY 4.0). Reused with credit; not modified.
- **Rows:** 12,435 (one sheet, `Sheet1`)
- Expected MD5: `564cacf0d27b9602f9fe83504770216e`

`R/01_load.R` checks the MD5 above before loading and stops if the file differs.

# Data dictionary

Source: S1 Data of Tanmoy et al. 2024 (see `raw/SOURCES.md`). One row per culture-confirmed *Salmonella* Typhi isolate, 1999 to 2022. Values below are the distinct values observed in the file on 20 October 2026 (full list with counts: `audit/raw_values.csv`).

| Column (cleaned name) | Meaning | Observed values | Missing | How it is used |
| --- | --- | --- | --- | --- |
| `ID` (`id`) | Anonymised isolate ID | 12,435 unique values | none | Uniqueness check only |
| `PatientType` (`patient_type`) | Where the sample came from | `IPD` 3,478; `OPD` 5,989; `Popular` 2,968 | none | Mapped to `inpatient`, `outpatient`, `community` |
| `Year` (`year`) | Year of blood collection | 1999 to 2022 | none | Time axis |
| `Amoxicillin` | Disc diffusion result | S, I, R | 4 | Co-primary outcome (susceptible = S) |
| `Chloramphenicol` | Disc diffusion result | S, I, R | 14 | Co-primary outcome |
| `Cotrimoxazole` | Disc diffusion result | S, I, R | 15 | Co-primary outcome |
| `Ciprofloxacin` | Disc diffusion result | S, I, R | 4 | Reproduction (non-susceptible = I or R) |
| `Ceftriaxone` | Disc diffusion result | S, R | 21 | Reproduction; descriptive only (2 resistant isolates) |
| `Azithromycin` | Disc diffusion, confirmed by Etest | S, R | 4,248 | Reproduction; descriptive only |
| `MDR` (`mdr`) | Resistant to amoxicillin, chloramphenicol and cotrimoxazole | `MDR` 3,425; `Not-MDR` 9,010 | none | Reproduction; exploratory outcome |
| `Ciprofloxacin_MIC` | Broth microdilution MIC (mg/L), subset | 3,214 values | 9,221 | Counted only; MIC modelling is deferred |
| `Ceftriaxone_MIC` | Broth microdilution MIC (mg/L), subset | 3,518 values, incl. 2 recorded as `>256` | 8,917 | Counted only; MIC modelling is deferred |

## Mapping rules (`sql/01_ast.sql`)

- Settings: `IPD` → inpatient, `OPD` → outpatient, `Popular` → community. Any other value stops the pipeline.
- Drug results: trimmed and upper-cased; `S`, `I` and `R` are valid; empty cells, `NA`, `N/A` and `-` are missing. Any other value stops the pipeline.
- MDR: `MDR` → 1; `Not-MDR` (and the spellings `NOT MDR`, `NOT_MDR`, `NON-MDR`, `NON MDR`) → 0.

## Outcome definitions

- **Susceptible to a drug:** S among isolates with a valid result (S, I or R) for that drug. I counts as not susceptible.
- **Resistant to a drug:** R among isolates with a valid result. Used to reproduce the paper's figures.
- **Ciprofloxacin non-susceptible:** I or R, as in the paper.
- **Susceptible to all three first-line drugs (exploratory):** S to amoxicillin, chloramphenicol and cotrimoxazole, among isolates with all three results valid.
- **MDR derived (check only):** R to all three, among isolates with all three results valid. I counts as not resistant.

## Breakpoints

The paper interpreted zone diameters and MICs using CLSI 2020 guidelines. S1 contains only the S, I and R categories, not zone diameters or QC records, so the categories are used exactly as published and cannot be re-interpreted or independently validated.

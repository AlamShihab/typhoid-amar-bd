# Reproduction notes

Each mismatch is classified as rounding, interpretation, missingness or a genuine inconsistency. The source file was never edited.

- **Ciprofloxacin non-susceptibility after 2001 (check R12b): interpretation of a summary statement.** The paper says non-susceptibility "remained above 90%" after reaching 95% in 2001. In S1 it was above 90% in every year after 2001 except 2003, when it was 86.2% among only 29 isolates. The paper's sentence describes the overall pattern rather than every small year.
- **Ciprofloxacin non-susceptibility in 2022 (check R11): rounding.** 1,266 of 1,298 is 97.5%, reported in the paper as 98%; the counts match exactly.
- **Average MDR since 2010 and since 2017 (checks R09 and R10): interpretation.** The paper's averages (20% and 17%) match the mean of yearly percentages (20.4% and 17.0%). The pooled proportions are 18.6% and 17.2%, so the paper averaged yearly values.
- **Supplied versus derived MDR (check R21):** the supplied MDR flag agrees with MDR derived from complete first-line panels in all 12,408 isolates with a complete panel. The 27 isolates without a complete panel keep their supplied flag (25 Not-MDR, 2 MDR) in the reproduction, and are excluded from the derived composites.

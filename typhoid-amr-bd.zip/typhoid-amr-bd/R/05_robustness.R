# Stage 5: robustness of the composition contrast (Delta) for the three first-line drugs.
source(here::here("R", "00_setup.R"))
source(here::here("R", "standardise_functions.R"))
set.seed(CFG$seed + 1)

es    <- readRDS(here("data", "processed", "endpoint_summary.rds"))
tiers <- readRDS(here("data", "processed", "tiers.rds"))
tier1 <- readRDS(here("data", "processed", "tier1_results.rds"))
tier2 <- readRDS(here("data", "processed", "tier2_results.rds"))
primary <- paste0("susceptible_", CFG$first_line)

delta_at <- function(curves, years) {
  curves |> filter(year %in% years) |> select(year, diff_est, diff_lo, diff_hi)
}

variant <- function(o, label, curves, years, model, tier_years) {
  delta_at(curves, years) |>
    mutate(outcome = o, variant = label, model = model, tier_years = tier_years, .before = 1)
}

span <- function(y) paste0(min(y), "-", max(y))

rows <- map_dfr(primary, \(o) {
  main <- tier1[[o]]
  if (!isTRUE(main$modellable)) return(NULL)
  ry <- intersect(CFG$report_years_t1, main$years)
  m_main <- fit_model(MODELS_TIER1[[main$chosen]], main$cells)
  out <- list(variant(o, "Main analysis", main$curves, ry, main$chosen, span(main$years)))

  # Reference weights: first year of the tier, and equal weights (same model and sample)
  first <- main$cells |> filter(year == min(year)) |> mutate(w_fix = n / sum(n)) |> select(setting, w_fix)
  equal <- tibble(setting = factor(CFG$hospital, CFG$hospital), w_fix = 0.5)
  out <- c(out, list(
    variant(o, paste0("Weights: mix in ", min(main$years)), standardise(m_main, main$cells, first),
            ry, main$chosen, span(main$years)),
    variant(o, "Weights: equal", standardise(m_main, main$cells, equal), ry, main$chosen, span(main$years))
  ))

  # Support threshold: re-derive the tier, rerun the model choice
  for (th in CFG$robust_n) {
    yrs <- tiers |> filter(outcome == o, threshold == th) |> pull(tier1) |> pluck(1)
    cells <- cells_for(es, o, CFG$hospital, yrs, th)
    sel <- choose_model(cells, MODELS_TIER1)
    m <- fit_model(MODELS_TIER1[[sel$best]], cells)
    out <- c(out, list(variant(o, paste0("Support threshold: ", th), standardise(m, cells, reference_weights(cells)),
                               intersect(ry, yrs), sel$best, span(yrs))))
  }

  # Model form: the candidates the leave-one-year-out rule did not choose
  for (nm in setdiff(names(MODELS_TIER1), main$chosen)) {
    m <- fit_model(MODELS_TIER1[[nm]], main$cells)
    out <- c(out, list(variant(o, paste0("Model form: ", nm), standardise(m, main$cells, main$weights),
                               ry, nm, span(main$years))))
  }

  # Trend shape: one straight-line year trend shared by both settings
  m <- fit_model(MODEL_PARALLEL_LINEAR, main$cells)
  out <- c(out, list(variant(o, "Trend shape: parallel straight lines", standardise(m, main$cells, main$weights),
                             ry, "parallel linear", span(main$years))))

  # Tier: three settings (Tier 2) against Tier 1 over the Tier 2 years
  t2 <- tier2[[o]]
  if (isTRUE(t2$modellable)) {
    ry2 <- intersect(CFG$report_years_t2, t2$years)
    out <- c(out, list(
      variant(o, "Tier 1 over the Tier 2 years (hospital mix only)", main$curves, ry2, main$chosen, span(main$years)),
      variant(o, "Tier 2 (adds the community centre)", t2$curves, ry2, t2$chosen, span(t2$years))
    ))
  }
  bind_rows(out)
})

robustness <- rows |> mutate(across(starts_with("diff"), \(x) 100 * x))   # percentage points
write_csv(robustness, here("audit", "robustness.csv"))
saveRDS(robustness, here("data", "processed", "robustness.rds"))

# ---- Optional: bootstrap of the model choice (off by default; slow) ----
if (CFG$run_bootstrap) {
  boot <- map_dfr(primary, \(o) {
    main <- tier1[[o]]
    ry <- intersect(CFG$report_years_t1, main$years)
    map_dfr(seq_len(CFG$n_boot), \(b) {
      cb  <- main$cells |> mutate(k = rbinom(n(), n, k / n))
      sel <- choose_model(cb, MODELS_TIER1)
      m   <- fit_model(MODELS_TIER1[[sel$best]], cb)
      cv  <- standardise(m, cb, main$weights, n_draws = 10)
      cv |> filter(year %in% ry) |> transmute(outcome = o, rep = b, chosen = sel$best, year, diff = 100 * diff_est)
    })
  })
  saveRDS(boot, here("data", "processed", "bootstrap_model_choice.rds"))
}

message("Robustness table: ", nrow(robustness), " rows (audit/robustness.csv).")

# Stage 3: reproduced published figures, coverage figures and descriptive drug trends.
source(here::here("R", "00_setup.R"))
dir.create(here("figures"), showWarnings = FALSE)

es <- readRDS(here("data", "processed", "endpoint_summary.rds"))
mix <- readRDS(here("data", "processed", "setting_mix.rds"))
cap <- source_caption()
pct_axis <- scale_y_continuous(labels = scales::percent, limits = c(0, 1))

label_outcome <- c(
  resistant_amx = "Amoxicillin resistant", resistant_chl = "Chloramphenicol resistant",
  resistant_sxt = "Cotrimoxazole resistant", mdr_supplied = "MDR (as supplied)",
  cip_nonsusceptible = "Ciprofloxacin non-susceptible (I or R)",
  resistant_cro = "Ceftriaxone resistant", resistant_azm = "Azithromycin resistant",
  susceptible_amx = "Amoxicillin", susceptible_chl = "Chloramphenicol", susceptible_sxt = "Cotrimoxazole",
  all3_susceptible = "Susceptible to all three (exploratory)", mdr_derived = "MDR (derived)"
)

trend_plot <- function(df, title, ylab) {
  df |>
    filter(n > 0) |>
    mutate(outcome = factor(label_outcome[outcome], levels = unique(label_outcome[outcome]))) |>
    ggplot(aes(year, est)) +
    geom_ribbon(aes(ymin = lo, ymax = hi), fill = "grey75", alpha = 0.6) +
    geom_line(colour = "grey15") +
    geom_point(aes(size = n), colour = "grey15") +
    facet_wrap(~ outcome) +
    pct_axis +
    scale_size_area(max_size = 2.6, name = "Isolates tested") +
    labs(title = title, x = NULL, y = ylab, caption = cap) +
    theme_report()
}

# ---- Reproduction of the paper's Figure 1 and Figure 2 (resistance, all settings) ----
p1 <- es |>
  filter(setting == "all", outcome %in% c("resistant_amx", "resistant_chl", "resistant_sxt", "mdr_supplied")) |>
  mutate(outcome = factor(outcome, c("resistant_amx", "resistant_chl", "resistant_sxt", "mdr_supplied"))) |>
  arrange(outcome) |>
  trend_plot("Reproduction of Figure 1: first-line resistance fell, MDR from 38% to 17%",
             "Resistant (R), 95% Wilson interval")
save_fig(p1, "fig_r1_reproduce_fig1", 9, 6)

p2 <- es |>
  filter(setting == "all", outcome %in% c("cip_nonsusceptible", "resistant_cro", "resistant_azm")) |>
  mutate(outcome = factor(outcome, c("cip_nonsusceptible", "resistant_cro", "resistant_azm"))) |>
  arrange(outcome) |>
  trend_plot("Reproduction of Figure 2: ciprofloxacin non-susceptibility stayed above 90%",
             "Proportion, 95% Wilson interval")
save_fig(p2, "fig_r2_reproduce_fig2", 10, 4.2)

# ---- Reproduction of S1 Fig: the paper counts community-centre cases as outpatient ----
s1 <- es |>
  filter(outcome == "mdr_supplied", setting %in% CFG$settings) |>
  mutate(group = if_else(setting == "inpatient", "Inpatient (IPD)", "Outpatient incl. community (OPD)")) |>
  group_by(year, group) |>
  summarise(k = sum(k), n = sum(n), .groups = "drop") |>
  add_wilson()
scale_n <- max(s1$n) * 1.05
p3 <- ggplot(s1, aes(year)) +
  geom_col(aes(y = n / scale_n, fill = group), position = "stack", alpha = 0.45, width = 0.8) +
  geom_line(aes(y = est, colour = group), linewidth = 0.8) +
  geom_point(aes(y = est, colour = group), size = 1.4) +
  scale_y_continuous(labels = scales::percent, name = "MDR (lines)",
                     sec.axis = sec_axis(~ . * scale_n, name = "Isolates (bars)")) +
  scale_fill_manual(values = c("#1f6fb2", "#e08a1e"), name = NULL) +
  scale_colour_manual(values = c("#1f6fb2", "#e08a1e"), name = NULL) +
  labs(title = "Reproduction of S1 Fig: yearly cases and MDR by hospitalisation status",
       subtitle = "As in the paper, community diagnostic centre cases are counted as outpatient",
       x = NULL, caption = cap) +
  theme_report()
save_fig(p3, "fig_r3_reproduce_s1fig", 9, 5)

# ---- Coverage grid (24 x 3) for the co-primary drugs ----
status_levels <- c("supported", "fewer than 30", "isolates, no valid result", "no isolates")
grid <- es |>
  filter(setting %in% CFG$settings, outcome %in% paste0("susceptible_", CFG$first_line)) |>
  mutate(drug = label_outcome[outcome],
         setting = factor(setting, rev(CFG$settings)),
         status = factor(status, status_levels))
p4 <- ggplot(grid, aes(year, setting, fill = status)) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = ifelse(n > 0, n, "")), size = 1.9, colour = "grey10") +
  facet_wrap(~ drug, ncol = 1) +
  scale_fill_manual(values = c("supported" = "#9ecae1", "fewer than 30" = "#fdd49e",
                               "isolates, no valid result" = "#fc8d59", "no isolates" = "grey88"),
                    drop = FALSE, name = NULL) +
  scale_x_continuous(breaks = seq(1999, 2022, 2), expand = c(0, 0)) +
  labs(title = "The community centre is absent 1999-2004 and 2010-2015 (one isolate in 2013)",
       subtitle = "Valid results per setting and year; cells with at least 30 are supported",
       x = NULL, y = NULL, caption = cap) +
  theme_report() + theme(panel.grid = element_blank())
save_fig(p4, "fig_c1_coverage_grid", 10, 6)

# ---- Setting mix by year ----
p5 <- mix |>
  mutate(setting = factor(setting, rev(CFG$settings))) |>
  ggplot(aes(year, share, fill = setting)) +
  geom_area(alpha = 0.85, colour = "white", linewidth = 0.2) +
  scale_fill_manual(values = SETTING_COLOURS, name = NULL) +
  scale_y_continuous(labels = scales::percent) +
  labs(title = "The mix of sampled settings changed sharply over 24 years",
       subtitle = "Share of isolates from each recorded setting, by year",
       x = NULL, y = "Share of isolates", caption = cap) +
  theme_report()
save_fig(p5, "fig_c2_setting_mix", 9, 4.5)

# ---- Descriptive susceptibility trends, by setting and pooled ----
susc <- es |>
  filter(outcome %in% paste0("susceptible_", CFG$first_line), setting %in% c(CFG$settings, "all"), n > 0) |>
  mutate(drug = factor(label_outcome[outcome], label_outcome[paste0("susceptible_", CFG$first_line)]),
         setting = factor(setting, c("all", CFG$settings)))
p6 <- ggplot(susc, aes(year, est, colour = setting)) +
  geom_line(data = filter(susc, setting == "all"), linewidth = 0.9) +
  geom_pointrange(data = filter(susc, setting != "all", n >= CFG$support_n),
                  aes(ymin = lo, ymax = hi), size = 0.18, alpha = 0.8,
                  position = position_dodge(width = 0.5)) +
  geom_point(data = filter(susc, setting != "all", n < CFG$support_n), shape = 1, size = 1.4,
             position = position_dodge(width = 0.5)) +
  facet_wrap(~ drug, ncol = 3) +
  pct_axis +
  scale_colour_manual(values = SETTING_COLOURS, name = NULL,
                      labels = c(all = "All settings (line)", inpatient = "Inpatient",
                                 outpatient = "Outpatient", community = "Community centre")) +
  labs(title = "Susceptibility to each first-line drug rose, in every setting",
       subtitle = "Susceptible (S); points with 95% Wilson intervals by setting; hollow points have fewer than 30 results",
       x = NULL, y = "Susceptible", caption = cap) +
  theme_report()
save_fig(p6, "fig_d1_susceptibility_by_setting", 11, 4.8)

p7 <- es |>
  filter(outcome %in% c("all3_susceptible", "mdr_supplied"), setting %in% c(CFG$settings, "all"), n > 0) |>
  mutate(outcome = factor(label_outcome[outcome], label_outcome[c("all3_susceptible", "mdr_supplied")]),
         setting = factor(setting, c("all", CFG$settings))) |>
  ggplot(aes(year, est, colour = setting)) +
  geom_line(data = \(d) filter(d, setting == "all"), linewidth = 0.8) +
  geom_point(data = \(d) filter(d, setting != "all", n >= CFG$support_n), size = 1, alpha = 0.8) +
  facet_wrap(~ outcome, ncol = 2) +
  pct_axis +
  scale_colour_manual(values = SETTING_COLOURS, name = NULL) +
  labs(title = "Exploratory composites: susceptible to all three, and MDR",
       x = NULL, y = "Proportion", caption = cap) +
  theme_report()
save_fig(p7, "fig_d2_exploratory_composites", 8, 3.8)

message("Saved descriptive figures to figures/.")

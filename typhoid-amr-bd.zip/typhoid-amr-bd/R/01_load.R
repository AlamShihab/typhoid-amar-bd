# Stage 1: load the workbook untouched, build the SQL views, and stop on any unexpected value.
source(here::here("R", "00_setup.R"))

src <- s1_path()
if (!file.exists(src)) {
  stop("Workbook not found: ", src, "\nDownload S1 Data (see data/raw/SOURCES.md) and save it there.")
}

# ---- Checksum: compare with SOURCES.md when an expected value has been recorded ----
md5 <- unname(tools::md5sum(src))
sources <- read_lines(here("data", "raw", "SOURCES.md"))
expected <- str_match(paste(sources, collapse = "\n"), "Expected MD5: `([0-9a-f]{32})`")[, 2]
if (!is.na(expected) && md5 != expected) {
  stop("Workbook MD5 ", md5, " does not match the value recorded in SOURCES.md (", expected, ").")
}
if (is.na(expected)) {
  message("No expected MD5 recorded yet. Add this line to data/raw/SOURCES.md:\n  Expected MD5: `", md5, "`")
}

# ---- Read every column as text from the first sheet ----
sheet <- excel_sheets(src)[1]
raw <- read_excel(src, sheet = sheet, col_types = "text")
names(raw) <- clean_names(names(raw))

required <- c("id", "patient_type", "year", "amoxicillin", "chloramphenicol", "cotrimoxazole",
              "ciprofloxacin", "ceftriaxone", "azithromycin", "mdr",
              "ciprofloxacin_mic", "ceftriaxone_mic")
missing_cols <- setdiff(required, names(raw))
if (length(missing_cols) > 0) {
  stop("Columns not found after cleaning names: ", paste(missing_cols, collapse = ", "),
       "\nColumns present: ", paste(names(raw), collapse = ", "),
       "\nRename them in R/01_load.R (the 'required' vector) or map them before loading.")
}

dir.create(here("audit"), showWarnings = FALSE)
dir.create(here("data", "processed"), showWarnings = FALSE)

# ---- Audit every distinct raw value ----
raw |>
  select(-id) |>
  mutate(across(everything(), as.character)) |>
  pivot_longer(everything(), names_to = "column", values_to = "value") |>
  count(column, value, name = "n") |>
  write_csv(here("audit", "raw_values.csv"), na = "<missing>")

write_lines(sprintf("%s  file=%s  sheet=%s  rows=%d  md5=%s",
                    format(Sys.time(), "%Y-%m-%d %H:%M:%S"), basename(src), sheet,
                    nrow(raw), md5),
            here("audit", "load_log.txt"), append = TRUE)

# ---- Database: raw table plus views ----
unlink(DB_PATH)
con <- db_connect()
on.exit(dbDisconnect(con, shutdown = TRUE), add = TRUE)

dbWriteTable(con, "ast_raw", raw[, required], overwrite = TRUE)
run_sql_files(con)

views <- dbGetQuery(con, "SELECT view_name FROM duckdb_views() WHERE NOT internal")$view_name
missing_views <- setdiff(EXPECTED_VIEWS, views)
if (length(missing_views) > 0) stop("Views not created: ", paste(missing_views, collapse = ", "))

# ---- Gate: no analysis until every unexpected value is resolved ----
bad <- dbGetQuery(con, "SELECT * FROM bad_values")
write_csv(bad, here("audit", "bad_values.csv"))
if (nrow(bad) > 0) {
  print(bad)
  stop("Unexpected values found (audit/bad_values.csv). Resolve each one with an explicit ",
       "mapping in sql/01_ast.sql or a stated exclusion, and record it in audit/discrepancies.md.")
}

message("Loaded ", nrow(raw), " rows; bad_values is empty.")

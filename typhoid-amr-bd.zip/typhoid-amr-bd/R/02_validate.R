# Stage 2: reproduction checks, endpoint summary, coverage audit, attrition and tiers.
source(here::here("R", "00_setup.R"))

con <- db_connect(read_only = TRUE)
on.exit(dbDisconnect(con, shutdown = TRUE), add = TRUE)
q <- function(sql) dbGetQuery(con, sql)

# ---- Hard stops: the analysis is defined for this exact file ----
n_rows <- q("SELECT COUNT(*) AS n FROM ast")$n
n_ids  <- q("SELECT COUNT(DISTINCT id) AS n FROM ast")$n
n_bad  <- nrow(q("SELECT * FROM bad_values"))
n_null_setting <- q("SELECT COUNT(*) AS n FROM ast WHERE setting IS NULL OR year IS NULL")$n
stopifnot(n_rows == 12435, n_ids == 12435, n_bad == 0, n_null_setting == 0)

# ---- Endpoint summary: full grid plus all-source and hospital-only rows ----
grid <- q("SELECT * FROM coverage_grid") |> as_tibble()
pooled <- function(df, label) {
  df |> group_by(outcome, year) |>
    summarise(k = sum(k), n = sum(n), n_isolates = sum(n_isolates), .groups = "drop") |>
    mutate(setting = label, status = NA_character_)
}
endpoint_summary <- bind_rows(
  grid,
  pooled(grid, "all"),
  pooled(filter(grid, setting %in% CFG$hospital), "hospital")
) |>
  add_wilson() |>
  arrange(outcome, setting, year)
write_csv(endpoint_summary, here("audit", "endpoint_summary.csv"), na = "")
saveRDS(endpoint_summary, here("data", "processed", "endpoint_summary.rds"))

es <- function(o, s = "all") filter(endpoint_summary, outcome == o, setting == s)
pct <- function(x) round(100 * x, 1)

# ---- Tiers, derived from the data (never typed into later stages) ----
derive_tiers <- function(outcome_name, threshold) {
  ok <- grid |> filter(outcome == outcome_name, n >= threshold)
  both_hosp <- ok |> filter(setting %in% CFG$hospital) |> count(year) |> filter(n == 2) |> pull(year)
  all_three <- ok |> count(year) |> filter(n == 3) |> pull(year)
  tibble(outcome = outcome_name, threshold = threshold,
         tier1 = list(longest_run(both_hosp)),
         tier2 = list(longest_run(all_three)),
         all_three_years = list(sort(all_three)),
         both_hosp_years = list(sort(both_hosp)))
}
model_outcomes <- c(paste0("susceptible_", CFG$first_line), "all3_susceptible", "mdr_supplied")
tiers <- map_dfr(c(CFG$support_n, CFG$robust_n), \(th) map_dfr(model_outcomes, derive_tiers, threshold = th))
saveRDS(tiers, here("data", "processed", "tiers.rds"))

span <- function(y) if (length(y) == 0) "none" else paste0(min(y), "-", max(y))
blocks <- function(y) {
  if (length(y) == 0) return("none")
  r <- split(y, cumsum(c(1, diff(y) != 1)))
  paste(map_chr(r, \(b) if (length(b) == 1) as.character(b) else paste0(min(b), "-", max(b))), collapse = ", ")
}
t_main <- tiers |> filter(threshold == CFG$support_n)

# ---- Reproduction checks ----
setting_n <- q("SELECT setting, COUNT(*) AS n FROM ast GROUP BY setting")
sn <- setNames(setting_n$n, setting_n$setting)
mdr <- es("mdr_supplied")
cip22 <- es("cip_nonsusceptible") |> filter(year == 2022)
cip_ns <- es("cip_nonsusceptible")
cro_r <- q("SELECT year, COUNT(*) AS n FROM ast WHERE cro = 'R' GROUP BY year ORDER BY year")
azm_first <- q("SELECT MIN(year) AS y FROM ast WHERE azm = 'R'")$y
valid <- q("SELECT drug, COUNT(*) FILTER (WHERE result IN ('S','I','R')) AS n FROM ast_long GROUP BY drug")
vn <- setNames(valid$n, valid$drug)
complete <- q("SELECT COUNT(*) AS n FROM first_line WHERE complete_panel")$n
mic <- q("SELECT
  COUNT(cip_mic_raw) AS cip_n, MIN(year) FILTER (WHERE cip_mic_raw IS NOT NULL) AS cip_y0,
  MAX(year) FILTER (WHERE cip_mic_raw IS NOT NULL) AS cip_y1,
  COUNT(cro_mic_raw) AS cro_n, MIN(year) FILTER (WHERE cro_mic_raw IS NOT NULL) AS cro_y0,
  MAX(year) FILTER (WHERE cro_mic_raw IS NOT NULL) AS cro_y1 FROM ast")
mdr_agree <- q("SELECT COUNT(*) FILTER (WHERE mdr_supplied <> mdr_derived) AS disagree,
                       COUNT(*) FILTER (WHERE mdr_derived IS NULL) AS not_derivable
                FROM first_line")
mean_yearly <- function(df, y0, y1) df |> filter(year >= y0, year <= y1) |> pull(est) |> mean()
t1_amx <- t_main |> filter(outcome == "susceptible_amx")

check <- function(id, item, expected, observed, match, source, tolerance = "exact") {
  tibble(id = id, item = item, expected = as.character(expected), observed = as.character(observed),
         tolerance = tolerance, source = source, status = if (isTRUE(match)) "match" else "check")
}
pp_ok <- function(obs, target, tol = 0.5) abs(100 * obs - target) <= tol
fmt <- function(x) format(x, big.mark = ",", trim = TRUE)

checks <- bind_rows(
  check("R01", "Rows in file", "12,435", fmt(n_rows), n_rows == 12435, "Paper"),
  check("R02", "Unique isolate IDs", "12,435", fmt(n_ids), n_ids == 12435, "Paper"),
  check("R03", "Unexpected values (bad_values)", "0 rows", n_bad, n_bad == 0, "Pipeline"),
  check("R04", "Hospital inpatients", "3,478 (28%)",
        sprintf("%s (%.1f%%)", format(sn[["inpatient"]], big.mark = ","), 100 * sn[["inpatient"]] / n_rows),
        sn[["inpatient"]] == 3478, "Paper"),
  check("R05", "Outpatient plus community", "8,957 (72%)",
        format(sn[["outpatient"]] + sn[["community"]], big.mark = ","),
        sn[["outpatient"]] + sn[["community"]] == 8957, "Paper"),
  check("R06", "Outpatient; community", "5,989; 2,968",
        paste0(fmt(sn[["outpatient"]]), "; ", fmt(sn[["community"]])),
        sn[["outpatient"]] == 5989 && sn[["community"]] == 2968, "Workbook count (reviewer)"),
  check("R07", "MDR in 1999", "38%", sprintf("%.1f%% (%d of %d)", 100 * mdr$est[mdr$year == 1999],
        mdr$k[mdr$year == 1999], mdr$n[mdr$year == 1999]),
        pp_ok(mdr$est[mdr$year == 1999], 38), "Paper", "within 0.5 points"),
  check("R08", "MDR in 2022", "17%", sprintf("%.1f%% (%d of %d)", 100 * mdr$est[mdr$year == 2022],
        mdr$k[mdr$year == 2022], mdr$n[mdr$year == 2022]),
        pp_ok(mdr$est[mdr$year == 2022], 17), "Paper", "within 0.5 points"),
  check("R09", "MDR, mean of yearly values 2010-2022", "20%",
        sprintf("%.1f%%", 100 * mean_yearly(mdr, 2010, 2022)),
        pp_ok(mean_yearly(mdr, 2010, 2022), 20), "Paper", "within 0.5 points"),
  check("R10", "MDR, mean of yearly values 2017-2022", "17%",
        sprintf("%.1f%%", 100 * mean_yearly(mdr, 2017, 2022)),
        pp_ok(mean_yearly(mdr, 2017, 2022), 17), "Paper", "within 0.5 points"),
  check("R11", "Ciprofloxacin non-susceptible, 2022", "1,266 of 1,298",
        paste0(fmt(cip22$k), " of ", fmt(cip22$n)), cip22$k == 1266 && cip22$n == 1298, "Paper"),
  check("R12", "Ciprofloxacin non-susceptible, 1999 and 2001", "56%; 95%",
        sprintf("%.1f%%; %.1f%%", 100 * cip_ns$est[cip_ns$year == 1999], 100 * cip_ns$est[cip_ns$year == 2001]),
        pp_ok(cip_ns$est[cip_ns$year == 1999], 56) && pp_ok(cip_ns$est[cip_ns$year == 2001], 95),
        "Paper", "within 0.5 points"),
  check("R12b", "Ciprofloxacin non-susceptible above 90% every year after 2001", "all years > 90%",
        { low <- filter(cip_ns, year > 2001, est <= 0.90)
          if (nrow(low) == 0) "all years > 90%" else
            paste0("below 90% in ", paste(sprintf("%d (%.1f%%, n = %d)", low$year, 100 * low$est, low$n), collapse = "; ")) },
        nrow(filter(cip_ns, year > 2001, est <= 0.90)) == 0, "Paper (text)"),
  check("R12c", "First-line resistance peaked at 80% in 2002", "80% in 2002",
        { r <- map_chr(c("amx", "chl", "sxt"), \(d) { x <- es(paste0("resistant_", d))
          sprintf("%s %.1f%% in %d", d, 100 * max(x$est, na.rm = TRUE), x$year[which.max(x$est)]) })
          paste(r, collapse = "; ") },
        all(map_lgl(c("amx", "chl", "sxt"), \(d) { x <- es(paste0("resistant_", d))
          x$year[which.max(x$est)] == 2002 && pp_ok(max(x$est, na.rm = TRUE), 80) })), "Paper", "within 0.5 points"),
  check("R12d", "MDR at most 26% since 2010 and at most 19% since 2017", "<= 26%; <= 19%",
        sprintf("max %.1f%%; max %.1f%%", 100 * max(mdr$est[mdr$year >= 2010]), 100 * max(mdr$est[mdr$year >= 2017])),
        round(100 * max(mdr$est[mdr$year >= 2010])) <= 26 && round(100 * max(mdr$est[mdr$year >= 2017])) <= 19,
        "Paper", "after rounding"),
  check("R13", "Ceftriaxone-resistant isolates", "2 (1999, 2000)",
        paste0(sum(cro_r$n), " (", paste(cro_r$year, collapse = ", "), ")"),
        sum(cro_r$n) == 2 && identical(as.integer(cro_r$year), c(1999L, 2000L)), "Paper"),
  check("R14", "First azithromycin-resistant isolate", "2013", azm_first, azm_first == 2013, "Paper"),
  check("R15", "Valid results: cipro; ceftriaxone; azithro", "12,431; 12,414; 8,187",
        paste(fmt(vn[["cip"]]), fmt(vn[["cro"]]), fmt(vn[["azm"]]), sep = "; "),
        vn[["cip"]] == 12431 && vn[["cro"]] == 12414 && vn[["azm"]] == 8187, "Paper"),
  check("R16", "Valid results: amox; chloram; cotrim", "12,431; 12,421; 12,420",
        paste(fmt(vn[["amx"]]), fmt(vn[["chl"]]), fmt(vn[["sxt"]]), sep = "; "),
        vn[["amx"]] == 12431 && vn[["chl"]] == 12421 && vn[["sxt"]] == 12420, "Workbook count (reviewer)"),
  check("R17", "Complete first-line panels", "12,408", fmt(complete), complete == 12408, "Workbook count (reviewer)"),
  check("R18", "Isolates with an MIC: cipro (years); ceftriaxone (years)",
        "3,214 (1999-2016); 3,518 (1999-2019)",
        sprintf("%s (%d-%d); %s (%d-%d)", fmt(mic$cip_n), mic$cip_y0, mic$cip_y1, fmt(mic$cro_n), mic$cro_y0, mic$cro_y1),
        mic$cip_n == 3214 && mic$cro_n == 3518, "Paper"),
  check("R19", "Years with >= 30 valid results in both hospital settings", "2004-2022",
        blocks(t1_amx$both_hosp_years[[1]]), identical(t1_amx$tier1[[1]], 2004:2022),
        "Workbook count (reviewer)"),
  check("R20", "Years with >= 30 in all three settings", "2005-2008, 2016-2022",
        blocks(t1_amx$all_three_years[[1]]),
        identical(t1_amx$all_three_years[[1]], c(2005:2008, 2016:2022)), "Workbook count (reviewer)"),
  check("R21", "Supplied MDR vs MDR derived from complete panels", "agree",
        sprintf("%d disagree; %d not derivable", mdr_agree$disagree, mdr_agree$not_derivable),
        mdr_agree$disagree == 0, "Pipeline")
)
write_csv(checks, here("audit", "reproduction_checks.csv"))
saveRDS(checks, here("data", "processed", "reproduction_checks.rds"))

# ---- Coverage and attrition ----
write_csv(grid, here("audit", "coverage_grid.csv"))

missing_results <- grid |>
  filter(outcome %in% paste0("susceptible_", names(CFG$drug_names))) |>
  mutate(drug = sub("susceptible_", "", outcome), n_missing = n_isolates - n) |>
  select(drug, year, setting, n_isolates, n_valid = n, n_missing)
write_csv(missing_results, here("audit", "missing_results.csv"))

incomplete_panels <- q("SELECT year, setting, COUNT(*) FILTER (WHERE NOT complete_panel) AS n_incomplete,
                               COUNT(*) AS n_isolates
                        FROM first_line GROUP BY year, setting ORDER BY year, setting")
write_csv(incomplete_panels, here("audit", "incomplete_panels.csv"))

attrition <- map_dfr(c(paste0("susceptible_", CFG$first_line), "all3_susceptible"), \(o) {
  g  <- filter(grid, outcome == o)
  tm <- filter(t_main, outcome == o)
  valid_n <- sum(g$n)
  steps <- tibble(
    step = c("All isolates", "Valid result for the outcome", "In supported cells (>= 30)",
             paste0("Tier 1 sample (hospital, ", span(tm$tier1[[1]]), ")"),
             paste0("Tier 2 sample (all three, ", span(tm$tier2[[1]]), ")")),
    n = c(n_rows, valid_n, sum(g$n[g$n >= CFG$support_n]),
          sum(g$n[g$setting %in% CFG$hospital & g$year %in% tm$tier1[[1]]]),
          sum(g$n[g$year %in% tm$tier2[[1]]]))
  )
  steps |> mutate(outcome = o, pct_of_isolates = 100 * n / n_rows,
                  pct_of_valid = if_else(row_number() == 1, NA_real_, 100 * n / valid_n), .before = 1)
})
write_csv(attrition, here("audit", "attrition.csv"))

threshold_share <- map_dfr(c(paste0("susceptible_", CFG$first_line)), \(o) {
  g <- filter(grid, outcome == o)
  map_dfr(sort(c(CFG$robust_n, CFG$support_n)), \(th) {
    tt <- filter(tiers, outcome == o, threshold == th)
    tibble(outcome = o, threshold = th,
           pct_in_supported_cells = 100 * sum(g$n[g$n >= th]) / sum(g$n),
           tier1_years = span(tt$tier1[[1]]), tier2_years = span(tt$tier2[[1]]))
  })
})
write_csv(threshold_share, here("audit", "threshold_share.csv"))

setting_mix <- q("SELECT year, setting, COUNT(*) AS n FROM ast GROUP BY year, setting") |>
  complete(year = CFG$years, setting = CFG$settings, fill = list(n = 0)) |>
  group_by(year) |> mutate(share = n / sum(n)) |> ungroup()
saveRDS(setting_mix, here("data", "processed", "setting_mix.rds"))

saveRDS(list(attrition = attrition, threshold_share = threshold_share,
             incomplete_panels = incomplete_panels, n_rows = n_rows),
        here("data", "processed", "coverage.rds"))

message("Reproduction checks: ", sum(checks$status == "match"), " match, ",
        sum(checks$status == "check"), " to review (audit/reproduction_checks.csv).")
message("Tier 1 (", CFG$support_n, "): ", span(t1_amx$tier1[[1]]),
        "; Tier 2: ", span(t1_amx$tier2[[1]]))

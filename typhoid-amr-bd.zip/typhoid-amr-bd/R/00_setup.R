# Shared settings and helpers. Every stage script sources this file first.

suppressPackageStartupMessages({
  library(DBI)
  library(duckdb)
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(readr)
  library(stringr)
  library(ggplot2)
  library(here)
})

# ---- Prespecified analysis settings (fixed before looking at results) ----
CFG <- list(
  years          = 1999:2022,
  settings       = c("inpatient", "outpatient", "community"),
  hospital       = c("inpatient", "outpatient"),
  first_line     = c("amx", "chl", "sxt"),
  drug_names     = c(amx = "Amoxicillin", chl = "Chloramphenicol", sxt = "Cotrimoxazole",
                     cip = "Ciprofloxacin", cro = "Ceftriaxone", azm = "Azithromycin"),
  support_n      = 30,      # a setting-year is supported if it has >= 30 valid results
  robust_n       = c(20, 50),
  min_events     = 10,      # modellable if the rarer category has >= 10 events ...
  min_event_frac = 2 / 3,   # ... in at least two-thirds of supported cells
  n_draws        = 5000,
  seed           = 20261021,
  report_years_t1 = c(2007, 2013, 2019),   # Delta reported at these interior years
  report_years_t2 = c(2017, 2019, 2021),
  run_bootstrap  = FALSE,   # optional model-choice bootstrap (slow)
  n_boot         = 200
)

DB_PATH <- here("data", "typhoid.duckdb")

s1_path <- function() here("data", "raw", "S1_Data.xlsx")

db_connect <- function(read_only = FALSE) {
  dbConnect(duckdb(), DB_PATH, read_only = read_only)
}

# Lower-case snake_case column names (replaces janitor::clean_names)
clean_names <- function(x) {
  x <- gsub("([a-z0-9])([A-Z])", "\\1_\\2", x)
  x <- tolower(x)
  x <- gsub("[^a-z0-9]+", "_", x)
  gsub("^_+|_+$", "", x)
}

# Run every SQL file in sql/, one view per file, in numbered order
run_sql_files <- function(con, dir = here("sql")) {
  files <- sort(list.files(dir, pattern = "\\.sql$", full.names = TRUE))
  for (f in files) dbExecute(con, read_file(f))
  invisible(files)
}

EXPECTED_VIEWS <- c("ast", "ast_long", "bad_values", "first_line", "year_setting",
                    "endpoints", "coverage_grid")

# Wilson score interval; a cell with n = 0 gets NA, never 0%
wilson <- function(k, n, z = qnorm(0.975)) {
  p      <- ifelse(n > 0, k / n, NA_real_)
  denom  <- 1 + z^2 / n
  centre <- (p + z^2 / (2 * n)) / denom
  half   <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / denom
  tibble(est = p,
         lo  = ifelse(n > 0, pmax(0, centre - half), NA_real_),
         hi  = ifelse(n > 0, pmin(1, centre + half), NA_real_))
}

add_wilson <- function(df) bind_cols(df, wilson(df$k, df$n))

# Longest run of consecutive years
longest_run <- function(y) {
  y <- sort(unique(y))
  if (length(y) == 0) return(integer(0))
  runs <- split(y, cumsum(c(1, diff(y) != 1)))
  runs[[which.max(lengths(runs))]]
}

# Data version string shown on every figure and in the report
data_version <- function() {
  f <- here("audit", "load_log.txt")
  if (!file.exists(f)) return("data version unknown")
  last <- tail(read_lines(f), 1)
  md5  <- str_match(last, "md5=([0-9a-f]+)")[, 2]
  paste0("S1 Data md5 ", substr(md5, 1, 8))
}

source_caption <- function() {
  paste0("Data: Tanmoy et al. 2024, PLoS NTD, S1 Data (CC BY 4.0). ", data_version(), ".")
}

theme_report <- function() {
  theme_minimal(base_size = 11) +
    theme(panel.grid.minor = element_blank(),
          plot.title = element_text(face = "bold", size = 12),
          plot.caption = element_text(size = 7.5, colour = "grey35", hjust = 0),
          legend.position = "bottom",
          strip.text = element_text(face = "bold"))
}

SETTING_COLOURS <- c(inpatient = "#1f6fb2", outpatient = "#e08a1e", community = "#3a9a5b",
                     all = "grey20", hospital = "#6b4ea0")

save_fig <- function(p, name, width = 8, height = 5) {
  ggsave(here("figures", paste0(name, ".png")), p, width = width, height = height,
         dpi = 160, bg = "white")
}

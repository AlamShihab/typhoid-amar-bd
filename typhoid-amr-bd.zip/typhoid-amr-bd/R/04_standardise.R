# Stage 4: how much does the recorded setting mix shape each first-line trend?
#   4a  hospital-only versus all-source estimates (descriptive)
#   4b  Tier 1: inpatient + outpatient, observed mix versus fixed mix (model-based)
#   4c  Tier 2: all three settings over the short common window
source(here::here("R", "00_setup.R"))
source(here::here("R", "standardise_functions.R"))
set.seed(CFG$seed)

es    <- readRDS(here("data", "processed", "endpoint_summary.rds"))
tiers <- readRDS(here("data", "processed", "tiers.rds"))
cap   <- source_caption()

primary     <- paste0("susceptible_", CFG$first_line)
exploratory <- c("all3_susceptible", "mdr_supplied")
outcome_label <- c(susceptible_amx = "Amoxicillin", susceptible_chl = "Chloramphenicol",
                   susceptible_sxt = "Cotrimoxazole", all3_susceptible = "All three (exploratory)",
                   mdr_supplied = "MDR (exploratory)")

# ---- 4a. Hospital-only versus all-source ----
source_cmp <- map_dfr(c(primary, exploratory), \(o) {
  d <- es |> filter(outcome == o, setting %in% CFG$settings)
  d |>
    mutate(group = if_else(setting == "community", "comm", "hosp")) |>
    group_by(year, group) |>
    summarise(k = sum(k), n = sum(n), .groups = "drop") |>
    pivot_wider(names_from = group, values_from = c(k, n), values_fill = 0) |>
    filter(n_comm > 0, n_hosp > 0) |>
    mutate(outcome = o,
           p_hosp = k_hosp / n_hosp, p_comm = k_comm / n_comm,
           p_all  = (k_hosp + k_comm) / (n_hosp + n_comm),
           w_comm = n_comm / (n_hosp + n_comm),
           shift  = p_all - p_hosp,                        # = w_comm * (p_comm - p_hosp)
           se     = w_comm * sqrt(p_comm * (1 - p_comm) / n_comm + p_hosp * (1 - p_hosp) / n_hosp),
           lo = shift - 1.96 * se, hi = shift + 1.96 * se,
           comm_supported = n_comm >= CFG$support_n)
})
saveRDS(source_cmp, here("data", "processed", "source_comparison.rds"))
write_csv(source_cmp, here("audit", "source_comparison.csv"))

p4a <- source_cmp |>
  filter(outcome %in% primary) |>
  mutate(outcome = factor(outcome_label[outcome], outcome_label[primary])) |>
  ggplot(aes(year, 100 * shift)) +
  geom_hline(yintercept = 0, colour = "grey50") +
  geom_errorbar(aes(ymin = 100 * lo, ymax = 100 * hi, alpha = comm_supported), width = 0.3) +
  geom_point(aes(shape = comm_supported), size = 1.8) +
  scale_shape_manual(values = c(`TRUE` = 16, `FALSE` = 1), name = "Community results >= 30",
                     labels = c(`TRUE` = "yes", `FALSE` = "no")) +
  scale_alpha_manual(values = c(`TRUE` = 1, `FALSE` = 0.35), guide = "none") +
  facet_wrap(~ outcome) +
  labs(title = "Adding the community centre moved pooled susceptibility by under 2 points, except in 2005",
       subtitle = "All-source minus hospital-only susceptibility, percentage points, years with community results; 95% interval",
       x = NULL, y = "Shift (percentage points)", caption = cap) +
  theme_report()
save_fig(p4a, "fig_s1_source_shift", 10, 4.2)

# ---- 4b. Tier 1 standardisation ----
run_tier <- function(o, tier_name, settings, models, threshold = CFG$support_n) {
  yrs <- tiers |> filter(outcome == o, threshold == !!threshold) |> pull(!!tier_name) |> pluck(1)
  if (length(yrs) < 4) return(NULL)
  cells <- cells_for(es, o, settings, yrs, threshold)
  ok <- modellable(cells)
  if (!ok) return(list(outcome = o, tier = tier_name, years = yrs, modellable = FALSE))
  w_fix <- reference_weights(cells)
  write_csv(w_fix, here("data", "processed", sprintf("weights_%s_%s.csv", tier_name, o)))  # before fitting
  sel <- choose_model(cells, models)
  m   <- fit_model(models[[sel$best]], cells)
  list(outcome = o, tier = tier_name, years = yrs, settings = settings, modellable = TRUE,
       cells = cells, weights = w_fix, scores = sel$scores, summary = sel$summary,
       chosen = sel$best, diagnostics = model_diagnostics(m),
       curves = standardise(m, cells, w_fix, CFG$n_draws), crude = crude_pooled(cells))
}

tier1 <- map(c(primary, exploratory), \(o) run_tier(o, "tier1", CFG$hospital, MODELS_TIER1)) |>
  set_names(c(primary, exploratory)) |> compact()
saveRDS(tier1, here("data", "processed", "tier1_results.rds"))

# ---- 4c. Tier 2: all three settings, short window, straight-line models only ----
tier2 <- map(c(primary, exploratory), \(o) run_tier(o, "tier2", CFG$settings, MODELS_TIER2)) |>
  set_names(c(primary, exploratory)) |> compact()
saveRDS(tier2, here("data", "processed", "tier2_results.rds"))

# ---- Figures ----
curve_df <- function(res, outs) {
  map_dfr(res[intersect(outs, names(res))], \(r) if (isTRUE(r$modellable)) mutate(r$curves, outcome = r$outcome))
}
crude_df <- function(res, outs) {
  map_dfr(res[intersect(outs, names(res))], \(r) if (isTRUE(r$modellable)) mutate(r$crude, outcome = r$outcome))
}

plot_curves <- function(res, outs, title, subtitle) {
  cv <- curve_df(res, outs) |> mutate(outcome = factor(outcome_label[outcome], outcome_label[outs]))
  cr <- crude_df(res, outs) |> mutate(outcome = factor(outcome_label[outcome], outcome_label[outs]))
  long <- bind_rows(
    cv |> transmute(outcome, year, mix = "Observed mix", est = obs_est, lo = obs_lo, hi = obs_hi),
    cv |> transmute(outcome, year, mix = "Fixed mix", est = fix_est, lo = fix_lo, hi = fix_hi)
  )
  ggplot(long, aes(year, est)) +
    geom_ribbon(aes(ymin = lo, ymax = hi, fill = mix), alpha = 0.2) +
    geom_line(aes(colour = mix), linewidth = 0.8) +
    geom_pointrange(data = cr, mapping = aes(x = year, y = est, ymin = lo, ymax = hi),
                    inherit.aes = FALSE, colour = "grey30", size = 0.15) +
    facet_wrap(~ outcome, scales = "free_y") +
    scale_y_continuous(labels = scales::percent) +
    scale_colour_manual(values = c("Observed mix" = "#1f6fb2", "Fixed mix" = "#c0392b"), name = NULL) +
    scale_fill_manual(values = c("Observed mix" = "#1f6fb2", "Fixed mix" = "#c0392b"), name = NULL) +
    labs(title = title, subtitle = subtitle, x = NULL, y = "Susceptible (model-based)", caption = cap) +
    theme_report()
}

plot_delta <- function(res, outs, title, subtitle) {
  curve_df(res, outs) |>
    mutate(outcome = factor(outcome_label[outcome], outcome_label[outs])) |>
    ggplot(aes(year, 100 * diff_est)) +
    geom_hline(yintercept = 0, colour = "grey50") +
    geom_ribbon(aes(ymin = 100 * diff_lo, ymax = 100 * diff_hi), fill = "grey70", alpha = 0.5) +
    geom_line(linewidth = 0.8) +
    facet_wrap(~ outcome) +
    labs(title = title, subtitle = subtitle, x = NULL,
         y = "Observed mix minus fixed mix (points)", caption = cap) +
    theme_report()
}

t1_span <- paste0(min(tier1[[1]]$years), " to ", max(tier1[[1]]$years))
p4b <- plot_curves(tier1, primary,
  "Tier 1: holding the inpatient/outpatient mix fixed barely changes the trends",
  paste0("Inpatient + outpatient, ", t1_span, "; lines are model estimates with pointwise 95% intervals; ",
         "grey points are crude pooled hospital estimates"))
save_fig(p4b, "fig_s2_tier1_standardised", 11, 4.6)
save_fig(plot_delta(tier1, primary, "Tier 1: the composition contrast stays within about 1 point in interior years",
                    paste0("Inpatient + outpatient, ", t1_span, "; pointwise 95% interval, conditional on the chosen model")),
         "fig_s3_tier1_delta", 10, 4)

if (length(tier2) > 0) {
  t2_span <- paste0(min(tier2[[1]]$years), " to ", max(tier2[[1]]$years))
  save_fig(plot_curves(tier2, primary,
    "Tier 2: with the community centre included, the two mixes still agree within 2 points",
    paste0("Inpatient + outpatient + community centre, ", t2_span, "; straight-line models")),
    "fig_s4_tier2_standardised", 11, 4.6)
}

message("Tier 1 models chosen: ",
        paste(map_chr(tier1, \(r) paste0(r$outcome, "=", r$chosen %||% "not modelled")), collapse = ", "))

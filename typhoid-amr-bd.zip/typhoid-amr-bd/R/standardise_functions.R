# Functions for the setting-mix standardisation (used by stages 4 and 5).
suppressPackageStartupMessages(library(mgcv))

YEAR_CENTRE <- 2013   # years are centred for numerical stability

# Candidate models, prespecified. Order is the tie-break preference (simplest first).
MODELS_TIER1 <- list(
  linear    = cbind(k, n - k) ~ setting * year_c,
  additive  = cbind(k, n - k) ~ setting + s(year_c, k = 8),
  deviation = cbind(k, n - k) ~ setting + s(year_c, k = 6, m = 2) + s(year_c, by = setting, k = 4, m = 1)
)
MODELS_TIER2 <- list(
  parallel = cbind(k, n - k) ~ setting + year_c,
  separate = cbind(k, n - k) ~ setting * year_c
)
MODEL_PARALLEL_LINEAR <- cbind(k, n - k) ~ setting + year_c

# Setting-year cells for one outcome; every requested cell must exist and be supported
cells_for <- function(es, outcome_name, settings, years, threshold = CFG$support_n) {
  cells <- es |>
    filter(outcome == outcome_name, setting %in% settings, year %in% years) |>
    select(outcome, year, setting, k, n) |>
    mutate(setting = factor(setting, levels = settings), year_c = year - YEAR_CENTRE) |>
    arrange(year, setting)
  stopifnot(nrow(cells) == length(settings) * length(years), all(cells$n >= threshold))
  cells
}

# At least min_events of the rarer category in at least two-thirds of cells
modellable <- function(cells) {
  rarer <- pmin(cells$k, cells$n - cells$k)
  mean(rarer >= CFG$min_events) >= CFG$min_event_frac
}

# Reference weights: pooled share of each setting over the cells used (declared before fitting)
reference_weights <- function(cells) {
  cells |> group_by(setting) |> summarise(n = sum(n), .groups = "drop") |>
    mutate(w_fix = n / sum(n)) |> select(setting, w_fix)
}

fit_model <- function(f, data) gam(f, family = quasibinomial, data = data, method = "REML")

# Leave-one-year-out: -2 x binomial log-likelihood of each held-out year's cells
loyo_folds <- function(cells, f) {
  map_dfr(sort(unique(cells$year)), \(y) {
    fit  <- fit_model(f, filter(cells, year != y))
    test <- filter(cells, year == y)
    p    <- predict(fit, test, type = "response")
    tibble(year = y, score = -2 * sum(dbinom(test$k, test$n, p, log = TRUE)))
  })
}

choose_model <- function(cells, models) {
  scores <- map_dfr(names(models), \(nm) mutate(loyo_folds(cells, models[[nm]]), model = nm))
  edge <- range(cells$year)
  summary <- scores |>
    group_by(model) |>
    summarise(total = sum(score),
              interior = sum(score[!year %in% edge]),
              .groups = "drop") |>
    mutate(model = factor(model, names(models))) |>
    arrange(model)
  best <- as.character(summary$model[which.min(summary$total)])
  best_interior <- as.character(summary$model[which.min(summary$interior)])
  # fold-by-fold differences from the chosen model: spread shows how decisive the choice is
  diffs <- scores |>
    left_join(filter(scores, model == best) |> select(year, best_score = score), by = "year") |>
    group_by(model) |>
    summarise(mean_diff = mean(score - best_score), sd_diff = sd(score - best_score),
              folds_better = sum(score < best_score), .groups = "drop")
  list(scores = scores,
       summary = left_join(mutate(summary, model = as.character(model)), diffs, by = "model"),
       best = best, best_interior = best_interior)
}

model_diagnostics <- function(m) {
  s <- summary(m)
  kc <- if (length(m$smooth) > 0) {
    as.data.frame(k.check(m)) |> tibble::rownames_to_column("smooth")
  } else NULL
  conc <- if (length(m$smooth) > 1) {
    as.data.frame(concurvity(m, full = TRUE)) |> tibble::rownames_to_column("measure")
  } else NULL
  list(scale = m$scale, edf_total = sum(m$edf), deviance_explained = s$dev.expl,
       k_check = kc, concurvity = conc)
}

coef_draws <- function(m, n_draws) {
  V <- if (!is.null(m$Vc)) m$Vc else m$Vp            # smoothing-parameter-corrected when available
  MASS::mvrnorm(n_draws, coef(m), V)
}

# Observed-mix and fixed-mix curves from the same predictions; only the weights differ
standardise <- function(m, cells, w_fix, n_draws = CFG$n_draws, draws = NULL) {
  cells <- cells |> group_by(year) |> mutate(w_obs = n / sum(n)) |> ungroup() |>
    left_join(w_fix, by = "setting")
  stopifnot(!anyNA(cells$w_fix))
  years <- sort(unique(cells$year))
  W_obs <- outer(years, cells$year, "==") * matrix(cells$w_obs, length(years), nrow(cells), byrow = TRUE)
  W_fix <- outer(years, cells$year, "==") * matrix(cells$w_fix, length(years), nrow(cells), byrow = TRUE)
  stopifnot(all(abs(rowSums(W_obs) - 1) < 1e-9), all(abs(rowSums(W_fix) - 1) < 1e-9))

  X  <- predict(m, cells, type = "lpmatrix")
  p0 <- plogis(drop(X %*% coef(m)))
  B  <- if (is.null(draws)) coef_draws(m, n_draws) else draws
  P  <- plogis(X %*% t(B))                            # cells x draws, response scale
  obs <- W_obs %*% P; fix <- W_fix %*% P; dif <- obs - fix
  qs <- function(M) t(apply(M, 1, quantile, probs = c(0.025, 0.975)))
  qo <- qs(obs); qf <- qs(fix); qd <- qs(dif)
  tibble(year = years,
         obs_est = drop(W_obs %*% p0), obs_lo = qo[, 1], obs_hi = qo[, 2],
         fix_est = drop(W_fix %*% p0), fix_lo = qf[, 1], fix_hi = qf[, 2],
         diff_est = drop(W_obs %*% p0 - W_fix %*% p0), diff_lo = qd[, 1], diff_hi = qd[, 2])
}

# Crude pooled estimate over the settings in the cells, for plotting beside the curves
crude_pooled <- function(cells) {
  cells |> group_by(year) |> summarise(k = sum(k), n = sum(n), .groups = "drop") |> add_wilson()
}

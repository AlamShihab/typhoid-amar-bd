-- One row per isolate and drug
CREATE OR REPLACE VIEW ast_long AS
SELECT id, year, setting, 'amx' AS drug, amx AS result FROM ast UNION ALL
SELECT id, year, setting, 'chl', chl FROM ast UNION ALL
SELECT id, year, setting, 'sxt', sxt FROM ast UNION ALL
SELECT id, year, setting, 'cip', cip FROM ast UNION ALL
SELECT id, year, setting, 'cro', cro FROM ast UNION ALL
SELECT id, year, setting, 'azm', azm FROM ast;

-- Cleaned isolate table. Explicit mappings only: anything not listed stays visible
-- (as an unmapped raw value) so that 03_bad_values.sql can stop the pipeline.
CREATE OR REPLACE VIEW ast AS
WITH r AS (
  SELECT
    TRIM(id) AS id,
    TRIM(year) AS year_raw,
    UPPER(TRIM(patient_type)) AS patient_type_raw,
    -- recognised missing-value tokens become NULL; every other value is kept as written
    CASE WHEN UPPER(TRIM(amoxicillin))     IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(amoxicillin))     END AS amx,
    CASE WHEN UPPER(TRIM(chloramphenicol)) IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(chloramphenicol)) END AS chl,
    CASE WHEN UPPER(TRIM(cotrimoxazole))   IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(cotrimoxazole))   END AS sxt,
    CASE WHEN UPPER(TRIM(ciprofloxacin))   IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(ciprofloxacin))   END AS cip,
    CASE WHEN UPPER(TRIM(ceftriaxone))     IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(ceftriaxone))     END AS cro,
    CASE WHEN UPPER(TRIM(azithromycin))    IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(azithromycin))    END AS azm,
    CASE WHEN UPPER(TRIM(mdr)) IN ('', 'NA', 'N/A', '-') THEN NULL ELSE UPPER(TRIM(mdr)) END AS mdr_raw,
    ciprofloxacin_mic AS cip_mic_raw,
    ceftriaxone_mic   AS cro_mic_raw
  FROM ast_raw
)
SELECT
  id,
  CAST(TRY_CAST(year_raw AS DOUBLE) AS INTEGER) AS year,
  CASE patient_type_raw
    WHEN 'IPD'     THEN 'inpatient'
    WHEN 'OPD'     THEN 'outpatient'
    WHEN 'POPULAR' THEN 'community'
  END AS setting,
  amx, chl, sxt, cip, cro, azm,
  CASE
    WHEN mdr_raw = 'MDR' THEN 1
    WHEN mdr_raw IN ('NOT-MDR', 'NOT MDR', 'NOT_MDR', 'NON-MDR', 'NON MDR') THEN 0
  END AS mdr,
  mdr_raw,
  cip_mic_raw,
  cro_mic_raw
FROM r;

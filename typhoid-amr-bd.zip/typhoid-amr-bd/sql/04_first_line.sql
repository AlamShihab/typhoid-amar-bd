-- Exploratory composites, defined only on complete, valid first-line panels.
-- MDR means R on all three drugs, so an I result counts as not resistant.
CREATE OR REPLACE VIEW first_line AS
WITH p AS (
  SELECT *,
    COALESCE(amx IN ('S', 'I', 'R') AND chl IN ('S', 'I', 'R') AND sxt IN ('S', 'I', 'R'), FALSE)
      AS complete_panel
  FROM ast
)
SELECT
  id, year, setting,
  mdr AS mdr_supplied,
  complete_panel,
  CASE WHEN NOT complete_panel THEN NULL
       WHEN amx = 'S' AND chl = 'S' AND sxt = 'S' THEN 1
       ELSE 0 END AS all3_s,
  CASE WHEN NOT complete_panel THEN NULL
       WHEN amx = 'R' AND chl = 'R' AND sxt = 'R' THEN 1
       ELSE 0 END AS mdr_derived
FROM p;

-- Every value that is not on an allowed list. Must return zero rows before analysis.
-- Missing drug results are allowed (they are counted separately); invalid ones are not.
CREATE OR REPLACE VIEW bad_values AS
SELECT 'setting' AS col, patient_type AS value, COUNT(*) AS n
FROM ast_raw
WHERE patient_type IS NULL OR UPPER(TRIM(patient_type)) NOT IN ('IPD', 'OPD', 'POPULAR')
GROUP BY patient_type
UNION ALL
SELECT 'year', year, COUNT(*)
FROM ast_raw
WHERE TRY_CAST(TRIM(year) AS DOUBLE) IS NULL
   OR TRY_CAST(TRIM(year) AS DOUBLE) <> FLOOR(TRY_CAST(TRIM(year) AS DOUBLE))
   OR TRY_CAST(TRIM(year) AS DOUBLE) NOT BETWEEN 1999 AND 2022
GROUP BY year
UNION ALL
SELECT 'mdr', mdr_raw, COUNT(*)
FROM ast
WHERE mdr_raw IS NOT NULL AND mdr IS NULL
GROUP BY mdr_raw
UNION ALL
SELECT 'drug result', drug || ': ' || result, COUNT(*)
FROM ast_long
WHERE result IS NOT NULL AND result NOT IN ('S', 'I', 'R')
GROUP BY drug, result
UNION ALL
SELECT 'blank id', NULL, COUNT(*)
FROM ast_raw
WHERE id IS NULL OR TRIM(id) = ''
HAVING COUNT(*) > 0
UNION ALL
SELECT 'duplicate id', TRIM(id), COUNT(*)
FROM ast_raw
WHERE id IS NOT NULL AND TRIM(id) <> ''
GROUP BY TRIM(id)
HAVING COUNT(*) > 1;

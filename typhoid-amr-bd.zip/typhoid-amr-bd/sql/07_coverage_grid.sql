-- Every outcome x year (1999-2022) x setting, so empty combinations appear as zeros.
CREATE OR REPLACE VIEW coverage_grid AS
WITH RECURSIVE yrs(year) AS (
  SELECT 1999 UNION ALL SELECT year + 1 FROM yrs WHERE year < 2022
),
grid AS (
  SELECT o.outcome, y.year, s.setting
  FROM (SELECT DISTINCT outcome FROM endpoints) o
  CROSS JOIN yrs y
  CROSS JOIN (VALUES ('inpatient'), ('outpatient'), ('community')) s(setting)
)
SELECT
  g.outcome, g.year, g.setting,
  COALESCE(e.k, 0)          AS k,
  COALESCE(e.n, 0)          AS n,
  COALESCE(i.n_isolates, 0) AS n_isolates,
  CASE WHEN COALESCE(i.n_isolates, 0) = 0 THEN 'no isolates'
       WHEN COALESCE(e.n, 0) = 0          THEN 'isolates, no valid result'
       WHEN e.n < 30                      THEN 'fewer than 30'
       ELSE 'supported' END AS status
FROM grid g
LEFT JOIN endpoints e
  ON e.outcome = g.outcome AND e.year = g.year AND e.setting = g.setting
LEFT JOIN year_setting i
  ON i.year = g.year AND i.setting = g.setting;

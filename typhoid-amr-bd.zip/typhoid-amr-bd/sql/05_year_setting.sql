-- Isolates per year and setting (observed combinations only; see 07 for the full grid)
CREATE OR REPLACE VIEW year_setting AS
SELECT year, setting, COUNT(*) AS n_isolates
FROM ast
GROUP BY year, setting;

-- One row per outcome, year and setting: numerator k and the outcome's own valid denominator n.
-- Resistance outcomes are for the reproduction; susceptibility outcomes are for the analysis.
CREATE OR REPLACE VIEW endpoints AS
SELECT 'susceptible_' || drug AS outcome, year, setting,
  COUNT(*) FILTER (WHERE result = 'S')               AS k,
  COUNT(*) FILTER (WHERE result IN ('S', 'I', 'R'))  AS n
FROM ast_long
GROUP BY drug, year, setting
UNION ALL
SELECT 'resistant_' || drug, year, setting,
  COUNT(*) FILTER (WHERE result = 'R'),
  COUNT(*) FILTER (WHERE result IN ('S', 'I', 'R'))
FROM ast_long
GROUP BY drug, year, setting
UNION ALL
SELECT 'cip_nonsusceptible', year, setting,
  COUNT(*) FILTER (WHERE result IN ('I', 'R')),
  COUNT(*) FILTER (WHERE result IN ('S', 'I', 'R'))
FROM ast_long
WHERE drug = 'cip'
GROUP BY year, setting
UNION ALL
SELECT 'mdr_supplied', year, setting,
  CAST(COALESCE(SUM(mdr_supplied), 0) AS BIGINT), COUNT(mdr_supplied)
FROM first_line
GROUP BY year, setting
UNION ALL
SELECT 'mdr_derived', year, setting,
  CAST(COALESCE(SUM(mdr_derived), 0) AS BIGINT), COUNT(mdr_derived)
FROM first_line
GROUP BY year, setting
UNION ALL
SELECT 'all3_susceptible', year, setting,
  CAST(COALESCE(SUM(all3_s), 0) AS BIGINT), COUNT(all3_s)
FROM first_line
GROUP BY year, setting;

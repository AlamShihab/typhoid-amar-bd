# Tests of the SQL definitions on small synthetic tables (no real data needed).
library(testthat)
library(DBI)
library(duckdb)

sql_dir <- here::here("sql")

make_db <- function(rows) {
  con <- dbConnect(duckdb())
  dbWriteTable(con, "ast_raw", as.data.frame(rows))
  for (f in sort(list.files(sql_dir, pattern = "\\.sql$", full.names = TRUE))) {
    dbExecute(con, readr::read_file(f))
  }
  con
}

base_row <- function(id, patient_type = "IPD", year = "2010", amx = "S", chl = "S", sxt = "S",
                     cip = "I", cro = "S", azm = "S", mdr = "Not-MDR") {
  tibble::tibble(id = id, patient_type = patient_type, year = year,
                 amoxicillin = amx, chloramphenicol = chl, cotrimoxazole = sxt,
                 ciprofloxacin = cip, ceftriaxone = cro, azithromycin = azm, mdr = mdr,
                 ciprofloxacin_mic = NA_character_, ceftriaxone_mic = NA_character_)
}

clean <- dplyr::bind_rows(
  base_row("a"),
  base_row("b", "OPD", amx = "R", chl = NA),            # incomplete panel
  base_row("c", "Popular", amx = "R", chl = "R", sxt = "R", mdr = "MDR"),
  base_row("d", "OPD", amx = "I", chl = "R", sxt = "R")  # I is not R: not MDR
)

dirty <- dplyr::bind_rows(
  clean,
  base_row("e", amx = "X"),                 # invalid category
  base_row("a"),                            # duplicate ID
  base_row(" ", "OPD"),                     # blank ID
  base_row("f", "Clinic"),                  # unknown setting
  base_row("g", year = "1998"),             # year out of range
  base_row("h", mdr = "maybe")              # unknown MDR value
)

test_that("every expected view is created", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  views <- dbGetQuery(con, "SELECT view_name FROM duckdb_views() WHERE NOT internal")$view_name
  expect_true(all(c("ast", "ast_long", "bad_values", "first_line", "year_setting",
                    "endpoints", "coverage_grid") %in% views))
})

test_that("a clean table passes the gate", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  expect_equal(nrow(dbGetQuery(con, "SELECT * FROM bad_values")), 0)
})

test_that("invalid values, IDs, settings, years and MDR spellings are caught", {
  con <- make_db(dirty); on.exit(dbDisconnect(con, shutdown = TRUE))
  bad <- dbGetQuery(con, "SELECT col, value FROM bad_values")
  expect_true(all(c("drug result", "duplicate id", "blank id", "setting", "year", "mdr") %in% bad$col))
  expect_true("amx: X" %in% bad$value)
})

test_that("an incomplete or invalid panel stays NULL in the composites", {
  con <- make_db(dirty); on.exit(dbDisconnect(con, shutdown = TRUE))
  fl <- dbGetQuery(con, "SELECT id, complete_panel, all3_s, mdr_derived FROM first_line")
  expect_true(is.na(fl$all3_s[fl$id == "b"]))
  expect_true(is.na(fl$mdr_derived[fl$id == "b"]))
  expect_false(fl$complete_panel[fl$id == "e"])   # 'X' is not a valid value
  expect_true(is.na(fl$all3_s[fl$id == "e"]))
})

test_that("MDR requires R on all three, and I is not R", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  fl <- dbGetQuery(con, "SELECT id, mdr_derived, mdr_supplied FROM first_line ORDER BY id")
  expect_equal(fl$mdr_derived[fl$id == "c"], 1)
  expect_equal(fl$mdr_derived[fl$id == "d"], 0)
  ok <- !is.na(fl$mdr_derived)
  expect_equal(fl$mdr_supplied[ok], fl$mdr_derived[ok])
})

test_that("denominators count valid results only", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  ep <- dbGetQuery(con, "SELECT SUM(n) AS n FROM endpoints WHERE outcome = 'susceptible_chl'")
  expect_equal(ep$n, 3)    # 'b' has no chloramphenicol result
  ep <- dbGetQuery(con, "SELECT SUM(n) AS n FROM endpoints WHERE outcome = 'all3_susceptible'")
  expect_equal(ep$n, 3)    # 'b' has an incomplete panel
})

test_that("tested plus missing equals isolates for every drug", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  chk <- dbGetQuery(con, "
    SELECT drug, COUNT(*) AS isolates,
           COUNT(*) FILTER (WHERE result IN ('S', 'I', 'R')) AS tested,
           COUNT(*) FILTER (WHERE result IS NULL) AS missing
    FROM ast_long GROUP BY drug")
  expect_equal(chk$tested + chk$missing, chk$isolates)
})

test_that("the coverage grid has 24 x 3 rows per outcome and empty cells are zero", {
  con <- make_db(clean); on.exit(dbDisconnect(con, shutdown = TRUE))
  g <- dbGetQuery(con, "SELECT outcome, COUNT(*) AS n FROM coverage_grid GROUP BY outcome")
  expect_true(all(g$n == 72))
  empty <- dbGetQuery(con, "SELECT * FROM coverage_grid WHERE year = 2000")
  expect_true(all(empty$n == 0))
  expect_true(all(empty$status == "no isolates"))
})

test_that("a cell with no valid results gets a missing estimate, not 0%", {
  source(here::here("R", "00_setup.R"))
  w <- wilson(k = c(0, 3), n = c(0, 10))
  expect_true(is.na(w$est[1]))
  expect_equal(w$est[2], 0.3)
  expect_true(w$lo[2] < 0.3 && w$hi[2] > 0.3)
})
